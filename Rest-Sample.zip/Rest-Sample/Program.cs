﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Rest_Sample.Data;
var builder = WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<Rest_SampleContext>(options =>
    options.UseSqlite(builder.Configuration.GetConnectionString("Rest_SampleContext") ?? throw new InvalidOperationException("Connection string 'Rest_SampleContext' not found.")));

// Add services to the container.

builder.Services.AddControllers();

// Authentication Provider
builder.Services.AddAuthentication("Bearer")
    .AddJwtBearer("Bearer", options =>
    {
        options.Authority = "http://localhost:5049";
        options.TokenValidationParameters =
        new Microsoft.IdentityModel.Tokens.TokenValidationParameters
        {
            ValidateAudience = false
        };
        options.RequireHttpsMetadata = false;
    });

var app = builder.Build();

// Configure the HTTP request pipeline.
app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();
